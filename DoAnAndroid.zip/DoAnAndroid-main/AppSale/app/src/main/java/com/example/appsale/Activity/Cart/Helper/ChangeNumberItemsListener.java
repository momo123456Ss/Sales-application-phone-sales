package com.example.appsale.Activity.Cart.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
