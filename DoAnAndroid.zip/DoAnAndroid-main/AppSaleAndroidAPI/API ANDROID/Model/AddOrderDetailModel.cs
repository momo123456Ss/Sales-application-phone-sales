﻿namespace API_ANDROID.Model
{
    public class AddOrderDetailModel
    {
        public int orderId { get; set; }
        public int productId { get; set; }
        public int num { get; set; }
    }
}
