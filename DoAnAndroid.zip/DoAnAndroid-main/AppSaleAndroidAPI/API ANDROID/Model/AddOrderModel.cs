﻿namespace API_ANDROID.Model
{
    public class AddOrderModel
    {
        public int userId { get; set; }
        public decimal totalPrice { get; set; }
        public string address { get; set; }
    }
}
