﻿namespace API_ANDROID.Model
{
    public class ChangePassModel
    {
        public string enpassword { get; set; }
    }
}
