﻿namespace API_ANDROID.Model
{
    public class ChangeRoleModel
    {
        public int roleid { get; set; }
    }
}
