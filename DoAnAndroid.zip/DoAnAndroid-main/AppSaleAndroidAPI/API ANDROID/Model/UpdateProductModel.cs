﻿namespace API_ANDROID.Model
{
    public class UpdateProductModel
    {
        public int num { get; set; }
        public decimal price { get; set; }
    }
}
